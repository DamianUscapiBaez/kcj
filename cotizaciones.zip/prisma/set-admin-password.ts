import "dotenv/config";
import { PrismaClient } from "../app/generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { hash } from "@node-rs/argon2";

const email = "admin@demo.cotizaciones.test";
const password = process.env.SEED_ADMIN_PASSWORD;
if (!password || password.length < 12) {
  throw new Error("Define SEED_ADMIN_PASSWORD (mínimo 12 caracteres) en .env antes de ejecutar este script.");
}
const prisma = new PrismaClient({
  adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL! }),
});

async function main() {
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) throw new Error(`No existe ${email}. Ejecuta primero prisma/seed.ts.`);
  await prisma.user.update({
    where: { id: user.id },
    data: { passwordHash: await hash(password!, { memoryCost: 19456, timeCost: 2, outputLen: 32, parallelism: 1 }) },
  });
  console.log(`Contraseña configurada para ${email}`);
}
main().catch((e) => { console.error(e); process.exitCode = 1; }).finally(() => prisma.$disconnect());
