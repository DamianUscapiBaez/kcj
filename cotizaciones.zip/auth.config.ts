import type { NextAuthConfig } from "next-auth";

export default {
  pages: { signIn: "/login" },
  providers: [],
  callbacks: {
    authorized({ auth, request: { nextUrl } }) {
      const loggedIn = !!auth?.user;
      const privateRoute = nextUrl.pathname.startsWith("/dashboard");
      if (privateRoute && !loggedIn) return false;
      if (loggedIn && nextUrl.pathname === "/login")
        return Response.redirect(new URL("/dashboard", nextUrl));
      return true;
    },
  },
} satisfies NextAuthConfig;
