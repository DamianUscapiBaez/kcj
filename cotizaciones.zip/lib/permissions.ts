import "server-only";
import { prisma } from "@/lib/prisma";
import { auth } from "@/auth";
import { redirect } from "next/navigation";
import type { CompanyRole } from "@/app/generated/prisma/client";

export async function getActiveMemberships(userId: string) {
  return prisma.companyUser.findMany({
    where: { userId, user: { isActive: true }, company: { isActive: true } },
    include: { company: true },
    orderBy: { joinedAt: "asc" },
  });
}

export async function requireCompanyAccess(userId: string, companyId?: string, allowedRoles?: CompanyRole[]) {
  const memberships = await getActiveMemberships(userId);
  const membership = companyId
    ? memberships.find((m) => m.companyId === companyId)
    : memberships[0];
  if (!membership) throw new Error("Acceso denegado: empresa no autorizada");
  if (allowedRoles && !allowedRoles.includes(membership.role))
    throw new Error("Acceso denegado: permisos insuficientes");
  return membership;
}

// Úsalo en cada Server Action y Route Handler que acceda a datos empresariales.
export async function requireAuthenticatedCompany(companyId: string, roles?: CompanyRole[]) {
  const session = await auth();
  if (!session?.user?.id) redirect("/login");
  return requireCompanyAccess(session.user.id, companyId, roles);
}
