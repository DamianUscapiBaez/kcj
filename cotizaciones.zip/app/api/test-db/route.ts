import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
    try {
        await prisma.$queryRaw`SELECT 1`;

        return NextResponse.json({
            success: true,
            message: "Conexión exitosa con PostgreSQL",
        });
    } catch (error) {
        console.error(error);

        return NextResponse.json(
            { success: false, message: "Error de conexión" },
            { status: 500 }
        );
    }
}