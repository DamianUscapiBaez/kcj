import { auth } from "@/auth";
import { redirect } from "next/navigation";
import { connection } from "next/server";
import LoginForm from "./login-form";

export default async function LoginSession() {
    await connection();

    const session = await auth();

    if (session?.user) {
        redirect("/dashboard");
    }

    return <LoginForm />;
}