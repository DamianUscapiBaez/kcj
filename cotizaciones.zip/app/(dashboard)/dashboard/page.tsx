import { auth } from "@/auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { requireCompanyAccess } from "@/lib/permissions";

export default async function DashboardPage() {
  const session = await auth();
  if (!session?.user?.id) redirect("/login");
  const company = await requireCompanyAccess(session.user.id);
  const [clients, quotations, services] = await Promise.all([
    prisma.client.count({ where: { companyId: company.companyId, isActive: true } }),
    prisma.quotation.count({ where: { companyId: company.companyId } }),
    prisma.service.count({ where: { companyId: company.companyId, isActive: true } }),
  ]);
  return (
    <section>
      <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
      <p className="mt-2 text-slate-500">Bienvenido, {session.user.name}. Rol: {company.role}</p>
      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        {[
          { label: "Clientes activos", value: clients },
          { label: "Cotizaciones", value: quotations },
          { label: "Servicios activos", value: services },
        ].map((item) => (
          <div key={item.label} className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
            <p className="text-sm text-slate-500">{item.label}</p>
            <p className="mt-2 text-3xl font-bold text-slate-900">{item.value}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
