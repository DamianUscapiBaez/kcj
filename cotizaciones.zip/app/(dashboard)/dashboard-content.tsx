import { auth } from "@/auth";
import { redirect } from "next/navigation";
import { connection } from "next/server";
import { requireCompanyAccess } from "@/lib/permissions";

// Conserva aquí los demás imports de tu page.tsx anterior.

export default async function DashboardContent() {
    await connection();

    const session = await auth();

    if (!session?.user?.id) {
        redirect("/login");
    }

    const company = await requireCompanyAccess(session.user.id);

    // A partir de aquí, conserva tus consultas originales
    // de clientes, cotizaciones y servicios,
    // así como todo el JSX del dashboard.
}