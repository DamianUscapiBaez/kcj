import { Suspense } from "react";
import DashboardContent from "./dashboard-content";

export default function DashboardPage() {
  return (
    <Suspense
      fallback={
        <div className="space-y-4">
          <h1 className="text-2xl font-bold text-slate-900">
            Dashboard
          </h1>

          <p className="text-sm text-slate-500">
            Cargando estadísticas...
          </p>
        </div>
      }
    >
      <DashboardContent />
    </Suspense>
  );
}